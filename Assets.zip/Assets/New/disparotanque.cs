using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class disparotanque : MonoBehaviour
{
    public GameObject balaPrefab;
    public Transform firePoint;
    public float velocidadBala = 20f;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            GameObject bala = Instantiate(balaPrefab, firePoint.position, firePoint.rotation);
            Rigidbody rb = bala.GetComponent<Rigidbody>();
            rb.velocity = firePoint.forward * velocidadBala;
        }
    }
}