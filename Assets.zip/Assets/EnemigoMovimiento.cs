using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemigoMovimiento : MonoBehaviour
{
    public float speed = 3f;
    private Vector3 direccion;

    void Start()
    {
        direccion = new Vector3(Random.Range(-1f, 1f), 0f, Random.Range(-1f, 1f)).normalized;
    }

    void Update()
    {
        transform.Translate(direccion * speed * Time.deltaTime, Space.World);

        Debug.DrawRay(transform.position, direccion * 0.5f, Color.red);

        Ray ray = new Ray(transform.position, direccion);
        if (Physics.Raycast(ray, 0.5f))
        {
            direccion = new Vector3(Random.Range(-1f, 1f), 0f, Random.Range(-1f, 1f)).normalized;
        }
    }
}
