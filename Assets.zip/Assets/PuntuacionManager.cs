using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PuntuacionManager : MonoBehaviour
{
    private int puntuacion = 0;

    void Start()
    {
        // Leer y mostrar puntuaci�n guardada
        int ultimaPuntuacion = PlayerPrefs.GetInt("Puntuacion", 0);
        Debug.Log("�ltima puntuaci�n: " + ultimaPuntuacion);

        // Iniciar impresi�n en consola cada 3 segundos
        StartCoroutine(ImprimirPuntuacionCada3Segundos());
    }

    public void SumarPunto()
    {
        puntuacion++;
        PlayerPrefs.SetInt("Puntuacion", puntuacion);
    }

    IEnumerator ImprimirPuntuacionCada3Segundos()
    {
        while (true)
        {
            Debug.Log("Puntuaci�n actual: " + puntuacion);
            yield return new WaitForSeconds(3f);
        }
    }
}
