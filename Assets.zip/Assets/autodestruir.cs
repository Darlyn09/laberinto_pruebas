using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class autodestruir : MonoBehaviour
{
    void Start()
    {
        Destroy(gameObject, 4f); // Destruye la bala despu�s de 4 segundos
    }
}
