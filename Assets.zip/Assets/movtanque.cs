using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movtanque : MonoBehaviour
{
    public float moveSpeed = 5f;  // Velocidad de movimiento
    public float turnSpeed = 100f; // Velocidad de rotaci�n

    void Update()
    {
        // Movimiento hacia adelante y hacia atr�s
        float move = Input.GetAxis("Vertical") * moveSpeed * Time.deltaTime;

        // Rotaci�n (izquierda y derecha)
        float turn = Input.GetAxis("Horizontal") * turnSpeed * Time.deltaTime;

        // Mover el tanque hacia adelante o atr�s
        transform.Translate(Vector3.forward * move);

        // Rotar el tanque
        transform.Rotate(Vector3.up * turn);
    }
}
