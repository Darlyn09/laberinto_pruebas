using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class disparotanque : MonoBehaviour
{
    public GameObject balaPrefab;      // Prefab de la bala
    public Transform firePoint;        // Punto de disparo
    public float velocidadBala = 20f;  // Velocidad de la bala

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            // Crea la bala en la posici�n y rotaci�n del FirePoint
            GameObject bala = Instantiate(balaPrefab, firePoint.position, firePoint.rotation);

            // Le da velocidad hacia adelante
            Rigidbody rb = bala.GetComponent<Rigidbody>();
            rb.velocity = firePoint.forward * velocidadBala;
        }
    }
}
